<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
            

            .mycolor{
            color : #72c02c;
        }        
        .myborder{
            background-color: white;
            padding: 20px;;
            border: 1px solid #ccc;
            border-radius: 4px;
            -webkit-box-shadow: 0px 0px 3px 0px #72c02c;
            -moz-box-shadow:    0px 0px 3px 0px #72c02c;
            box-shadow:         0px 0px 3px 0px #72c02c;
        }
        .mybutton{
            position: relative;
            left: 50%;
            top: 193px;

        }
        .margin-bottom-20 {
            margin-bottom: 20px;

        }
        .btn-u:hover {
            background: #5fb611;
        }
        .btn-u:hover, .btn-u:focus, .btn-u:active, .btn-u.active, .open .dropdown-toggle.btn-u {
            background: #5fb611;
        }
        .btn-u:hover {
            color: #fff;
            text-decoration: none;
            -webkit-transition: all 0.3s ease-in-out;
            -moz-transition: all 0.3s ease-in-out;
            -o-transition: all 0.3s ease-in-out;
            transition: all 0.3s ease-in-out;
        }
        .btn-u {
            background: #72c02c;
        }
        .btn-u {
            white-space: nowrap;
            border: 0;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            font-weight: 400;
            padding: 6px 13px;
            position: relative;
            background: #72c02c;
            display: inline-block;
            text-decoration: none;
        }
        .input-group-addon {
            border-right: 0;
            /*color: #b3b3b3;*/
            font-size: 14px;
            background: #fff;
            padding: 6px 12px;
            font-size: 14px;
            font-weight: 400;
            line-height: 1;
            color: #555;
            text-align: center;
            background-color: #eee;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .input-group .form-control {
            float: left;
            width: 100%;
            margin-bottom: 0;
        }
        .form-control {
            box-shadow: none;
        }
        .form-control {
            display: block;
            width: 100%;
            height: 34px !important;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.428571429;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid  #72c02c !important;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            -webkit-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        }        .mycolor{
            color : #72c02c;
        }        
        .myborder{
            padding: 20px;;
            border: 1px solid #ccc;
            border-radius: 4px;
            -webkit-box-shadow: 0px 0px 3px 0px #72c02c;
            -moz-box-shadow:    0px 0px 3px 0px #72c02c;
            box-shadow:         0px 0px 3px 0px #72c02c;
        }
        .mybutton{
            position: relative;
            left: 50%;
            top: 193px;

        }
        .margin-bottom-20 {
            margin-bottom: 20px;

        }
        .btn-u:hover {
            background: #5fb611;
        }
        .btn-u:hover, .btn-u:focus, .btn-u:active, .btn-u.active, .open .dropdown-toggle.btn-u {
            background: #5fb611;
        }
        .btn-u:hover {
            color: #fff;
            text-decoration: none;
            -webkit-transition: all 0.3s ease-in-out;
            -moz-transition: all 0.3s ease-in-out;
            -o-transition: all 0.3s ease-in-out;
            transition: all 0.3s ease-in-out;
        }
        .btn-u {
            background: #72c02c;
        }
        .btn-u {
            white-space: nowrap;
            border: 0;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            font-weight: 400;
            padding: 6px 13px;
            position: relative;
            background: #72c02c;
            display: inline-block;
            text-decoration: none;
        }
        .input-group-addon {
            border-right: 0;
            /*color: #b3b3b3;*/
            font-size: 14px;
            background: #fff;
            padding: 6px 12px;
            font-size: 14px;
            font-weight: 400;
            line-height: 1;
            color: #555;
            text-align: center;
            background-color: #eee;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .input-group .form-control {
            float: left;
            width: 100%;
            margin-bottom: 0;
        }
        .form-control {
            box-shadow: none;
        }
        .form-control {
            display: block;
            width: 100%;
            height: 34px !important;
            padding: 6px 12px;
            font-size: 14px;
            line-height: 1.428571429;
            color: #555;
            background-color: #fff;
            background-image: none;
            border: 1px solid  #72c02c !important;
            border-radius: 4px;
            -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
            -webkit-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
            transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
        }
</style>

<meta http-equiv="Content-type" content="text/html; charset=utf-8" />



    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="airbnb.css">
<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>


<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


        

    <!-- JS -->
    <script src="js/jquery-1.4.1.min.js" type="text/javascript"></script>   
    <script src="js/jquery.jcarousel.pack.js" type="text/javascript"></script>  
    <script src="js/jquery-func.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    <!-- End JS -->
</head>



<body>
<body id="page-top" class="index">

    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="airbnb.php" style="color: rgb(0,128,128); font-family: Arial Black;"><img src="images/logo.png"  style="float:left; padding-right: 10px; margin-top: -10px;"><b>DELACO</b></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="airbnb.php"><span class="glyphicon glyphicon-home"></span></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="browse_items.php">Browse Items</a>
                    </li>
                    
                    <?php
                    if (!$_SESSION['login_user']){ ?>
                      <li>
                          <a class="page-scroll" href="login.php">Login</a>
                      </li>
                       <li>
                          <a class="page-scroll" href="signup.php">Sign up</a>
                      </li>
                    <?php } else {?>
                      <li>
                          <a class="page-scroll" href="myitem.php">My Item</a>
                      </li>
                      <li>
                          <a class="page-scroll" href="logout.php">Log Out</a>
                      </li>
                    <?php } ?>
                    
                    
                </ul>


                
    <form class="navbar-form navbar-left" role="search" action="search_results2.php" method="POST">
      <div class="form-group">
          <input type="text" class="form-control" placeholder="Item" id="name" name="name">
      </div>
      <button type="button" class="btn btn-info">
        <span class="glyphicon glyphicon-search"></span> Search
      </button>
    </form>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    
<hr>
<hr>
<hr>


<div class="container">
    <div class="col-md-3"></div>
    <div class="col-md-6">
         <div class="row myborder">
            <h4 style="color: black; margin: initial; margin-bottom: 10px;">Create your account</h4><hr>
        <form action="registration.php" method="POST">
            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="First Name" name="fname" id="UserRegistration_fname" type="text">
            </div>
            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="Last Name" name="lname" id="UserRegistration_lname" type="text">
            </div>
            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="User Name" name="username" id="UserRegistration_username" type="text">
            </div>
            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="Password" name="password" id="UserRegistration_password" type="password">
            </div>

            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="Email Address" name="email" id="UserRegistration_emailaddress" type="email">
            </div>
            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="Phone Number" name="phone" id="UserRegistration_phonenumber" type="number">
            </div>

            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="Zipcode" name="zipcode" id="UserRegistration_zipcode" type="number">
            </div>

            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="City" name="city" id="UserRegistration_city" type="text">
            </div>
            <div class="input-group margin-bottom-20">
                <input size="60" maxlength="255" class="form-control" placeholder="Address" name="address" id="UserRegistration_address" type="text">
            </div>
            <div class="row">
                <div class="col-md-12">
                    <input class="btn-u pull-left" type="submit" name="submit" value="Create Account">
                </div>
            <hr>
            </div>
        </form>
        <div class="col-md-2">
            <button class="btn-u pull-left" type="back">Back</button> </div>
        </div>
    </div>
    </div>


 <hr>                


<footer class="text-muted well" id="last-footer">
    <section>
    <div class="row" style="font-size:11px;">
    <div class="container">
    <h3 class="subhead" style="text-align:center;">Thanks for visiting our website</h3>

      <div class="col-md-9">
      <div class="row" >
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="aboutus.php" style="color: white"><h5>About US</h5></a></button>
      </div>
      </div>
      </div>
      
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="faq.php" style="color: white"><h5>FAQs</h5></a></button>
      </div>
      </div>
      </div>
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <h5 style= "text-align: center;">Contact US</h5>
      <h7 allign="justify">Delaco (Main office) <br>Kotkantie 1, 90250<br>Oulu, Finland</h7>
      </div>
      </div>
      </div>
      <hr/>     
        </div><!--/.row inner--> 
    </div>
    
          </ul>   
        </form>   
    </div>
    </div>
      <footer>  <div class="row">
      <div class="container text-center">
        <h5>All Rights Reserved © 2017.</h5>
      </div>
      </div></footer>
       </div><!--/.container--> 
       </div><!--/.row outer--> 
    </section>
        </footer> 
     </div>
  
    
  


        <script src="js/bootstrap.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</body>
</html>