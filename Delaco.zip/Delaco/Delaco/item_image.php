<?php
include("db.php");
header("Content-type: image/jpeg");
$id = (int)$_GET['id'];
$query = "SELECT * from items WHERE itemid = ".$id;
$result = mysqli_query($db,$query);
$item = mysqli_fetch_assoc($result);
echo $item['img'];

?>