<?php
include("db.php");
session_start();
$user_id = $_SESSION['login_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    // cleaning title field
	$title		=mysqli_real_escape_string($db,$_POST['title']); 
	$description=mysqli_real_escape_string($db,$_POST['description']); 
	$ppd 		=mysqli_real_escape_string($db,$_POST['ppd']); 
	$deposit	=mysqli_real_escape_string($db,$_POST['deposit']); 
	$location 	=mysqli_real_escape_string($db,$_POST['location']); 
    if (isset($_FILES['photo']))
    {
		$data = addslashes(file_get_contents($_FILES['photo']['tmp_name']));
        $sql = "INSERT INTO items (ownerid, title, description, priceperday, deposit, location, img) VALUES ('$user_id','$title','$description','$ppd','$deposit','$location','$data');";
    }
    $result = mysqli_query($db,$sql);
	header('Location: myitem.php');
}
?>