<?php
session_start();
?>
<!DOCTYPE html >
<html>
<head>

<meta http-equiv="Content-type" content="text/html; charset=utf-8" />



    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="airbnb.css">
<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>


<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


        

    <!-- JS -->
    <script src="js/jquery-1.4.1.min.js" type="text/javascript"></script>   
    <script src="js/jquery.jcarousel.pack.js" type="text/javascript"></script>  
    <script src="js/jquery-func.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    <!-- End JS -->
</head>



<body>
<body id="page-top" class="index">

    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="airbnb.php" style="color: rgb(0,128,128); font-family: Arial Black;"><img src="images/logo.png"  style="float:left; padding-right: 10px; margin-top: -10px;"><b>DELACO</b></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="airbnb.php"><span class="glyphicon glyphicon-home"></span></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="browse_items.php">Browse Items</a>
                    </li>
                    
                    <?php
                    if (!$_SESSION['login_user']){ ?>
                      <li>
                          <a class="page-scroll" href="login.php">Login</a>
                      </li>
                       <li>
                          <a class="page-scroll" href="signup.php">Sign up</a>
                      </li>
                    <?php } else {?>
                      <li>
                          <a class="page-scroll" href="myitem.php">My Item</a>
                      </li>
                      <li>
                          <a class="page-scroll" href="logout.php">Log Out</a>
                      </li>
                    <?php } ?>
                    
                    
                </ul>


                
    <form class="navbar-form navbar-left" role="search" action="search_results2.php" method="POST">
      <div class="form-group">
          <input type="text" class="form-control" placeholder="Item" id="name" name="name">
      </div>
      <button type="button" class="btn btn-info">
        <span class="glyphicon glyphicon-search"></span> Search
      </button>
    </form>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    
<hr>
<hr>
<hr>
<div class="boxed">
 <h3>My Items</h3>
</div>

<div class="container" style="background-color: white;">
<form action="delete.php" method="POST">
<table class="table" style="margin:px;">
  <thead class="thead-inverse">
    <tr>
      <th>Image</th>
      <th>Title</th>
      <th>Discription</th>
      <th>Price/Day</th>
      <th>Diposit</th>
      <th>Location</th>
      <th>Remove</th>
      
       
      

    </tr>
  </thead>
  <tbody>
  <?php
    include("db.php");

    session_start();
    $user_id = $_SESSION['login_id'];
    $message = $_SESSION['message'];
    $sql = "SELECT * FROM items WHERE ownerid='$user_id'";
    $result = mysqli_query($db,$sql);
  ?>
      <?php
      while($row = mysqli_fetch_array($result))
      {
      echo "<tr>";
      echo '<th scope="row"><img src="data:image/jpeg;base64,'.base64_encode($row['img'] ).'" class="img-fluid col-lg-12" alt="Responsive image" style=\"height:10%; width:10%;\"/></th>';
      echo "<td class='col-lg-3'>" . $row['title'] . "</td>";
      echo "<td class='col-lg-3'>" . $row['description'] . "</td>";
      echo "<td class='col-lg-1'>" . $row['priceperday'] . "</td>";
      echo "<td class='col-lg-1'>" . $row['deposit'] . "</td>";
      echo "<td class='col-lg-1'>" . $row['location'] . "</td>";
      echo "<td class='col-lg-1'><a href='delete.php?id=".$row["itemid"] ."'><span class=\"glyphicon glyphicon-trash\"></span></a></td>";
      echo "</tr>";
      }
      ?>
      <!--<th scope="row"> <img src="images/bluetooth speaker.jpg" class="img-fluid" alt="Responsive image""  style="height:25%; width:25%;"/></th>
      <td>Beats Bluetooth Speaker</td>
      <td>Beats Bluetooth Speaker</td>
      <td>10€</td>
      <td>120€</td>
      <td>Linnanmaa</td>
      <td><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" ><span class="glyphicon glyphicon-trash"></span></button>
      </td>-->
    
  </tbody>
</table>
</form>
<?php
echo '<br><a href="upload.php" style="color:white;"><button class="btn btn-info">
  Create
  </button></a>';
?>
</div>
<hr>
<footer class="text-muted well" id="last-footer">
    <section>
    <div class="row" style="font-size:11px;">
    <div class="container">
    <h3 class="subhead" style="text-align:center;">Thanks for visiting our website</h3>
      <div class="col-md-9">
      <div class="row" >
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="aboutus.php" style="color: white"><h5>About US</h5></a></button>
      </div>
      </div>
      </div>
      
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="faq.php" style="color: white"><h5>FAQs</h5></a></button>
      </div>
      </div>
      </div>
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <h5 style= "text-align: center;">Contact US</h5>
      <h7 allign="justify">Delaco (Main office) <br>Kotkantie 1, 90250<br>Oulu, Finland</h7>
      </div>
      </div>
      </div>
      <hr/>     
        </div><!--/.row inner--> 
    </div>
    
          </ul>   
        </form>   
    </div>
    </div>
      <footer>  <div class="row">
      <div class="container text-center">
        <h5>All Rights Reserved © 2017.</h5>
      </div>
      </div></footer>
       </div><!--/.container--> 
       </div><!--/.row outer--> 
    </section>
        </footer> 
     </div>
  
    
  
        <script src="js/bootstrap.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>