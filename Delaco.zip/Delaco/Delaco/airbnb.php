<?php
session_start();
?>

<!DOCTYPE html >
<html>
<head>

<meta http-equiv="Content-type" content="text/html; charset=utf-8" />



    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="airbnb.css">
<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>


<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


        

    <!-- JS -->
    <script src="js/jquery-1.4.1.min.js" type="text/javascript"></script>   
    <script src="js/jquery.jcarousel.pack.js" type="text/javascript"></script>  
    <script src="js/jquery-func.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    <!-- End JS -->
</head>



<body>
<body id="page-top" class="index">

    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="airbnb.php" style="color: rgb(0,128,128); font-family: Arial Black;"><img src="images/logo.png"  style="float:left; padding-right: 10px; margin-top: -10px;"><b>DELACO</b></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="airbnb.php"><span class="glyphicon glyphicon-home"></span></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="browse_items.php">Browse Items</a>
                    </li>
                    
                    <?php
                    if (!$_SESSION['login_user']){ ?>
                      <li>
                          <a class="page-scroll" href="login.php">Login</a>
                      </li>
                       <li>
                          <a class="page-scroll" href="signup.php">Sign up</a>
                      </li>
                    <?php } else {?>
                      <li>
                          <a class="page-scroll" href="myitem.php">My Item</a>
                      </li>
                      <li>
                          <a class="page-scroll" href="logout.php">Log Out</a>
                      </li>
                    <?php } ?>
                </ul>


                
    <form class="navbar-form navbar-left" role="search" action="search_results2.php" method="POST">
      <div class="form-group">
        <input type="text" class="form-control" placeholder="Item" id="name" name="name">
      </div>
      <button type="button" class="btn btn-info">
        <span class="glyphicon glyphicon-search"></span> Search
      </button>
    </form>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    
<hr>



<!--image carousel-->
<div id= "myCarousel" class="carousel slide">
 
 <ol class = "carousel-indicators">
 <li data-target = "#myCarousel" data-slide-to ="0" class = "active"></li>
 <li data-target = "#myCarousel" data-slide-to ="1"></li>
 <li data-target = "#myCarousel" data-slide-to ="2"></li>
 <li data-target = "#myCarousel" data-slide-to ="3"></li>
 </ol>

 <div class = "carousel-inner">

 <div class = "item active">
 <img src ="images/handshake.jpg" alt = "Beach" class="img-responsive">
 <div class= "carousel-caption">
 <h3></h3>

 </div> 
 </div>

 <div class = "item">
 <img src ="images/cartoon.png" alt = "Beach" class="img-responsive">
 <div class= "carousel-caption">
 <h3 style="color:rgb(46,208,35)">Delaco "Share It"</h3>
 </div>
 </div>

<div class = "item">
 <img src ="images/payment1.png" alt = "Beach" class="img-responsive">
 <div class= "carousel-caption">
 <h3 style="color:rgb(46,208,35)">Secure payment gateway</h3>
 </div> 
 </div>

<div class = "item">
 <img src ="images/oulu.jpg" alt = "Beach" class="img-responsive">
 <div class= "carousel-caption">
 <h3 style="color:rgb(46,208,35)">Currently based in Oulu</h3>
 </div> 
 </div>

 </div>

 <a class= "carousel-control left" href ="#myCarousel" data-slide = "prev"> 
 <span class = "icon-prev"></span></a> 

 <a class= "carousel-control right" href ="#myCarousel" data-slide = "next"> 
 <span class = "icon-next"></span></a> 

</div>
<!--image carousel ends-->


<hr>


<div class="boxed">
 <h3>Top items of the week!</h3>
</div>

<?php
include("db.php");
$query = "SELECT * from items ORDER BY itemid LIMIT 0,6";
$result = mysqli_query($db,$query);


while($item = mysqli_fetch_assoc($result)) {

	echo '<div class="col-md-4">';
    echo '<div class="thumbnail">';
    echo '<img src="item_image.php?id='.$item['itemid'].'" alt="books" class="img-rounded" height="200" width="350">';
    echo '<div class="caption">';
    echo '<p text align="center" style="color: green;">'.$item['title'].'<br><span class="glyphicon glyphicon-map-marker"></span>'.$item['location'].'<br>Deposit: '.$item['deposit'].'€, Price: '.$item['priceperday'].'€/day </p>';
    echo '<div class="center">';
    echo '<button type="button" class="btn btn-info"><a href="#" style="color:white;">Hire This Item<a></button></a></div>';
    echo '</div>';
    echo '</div>';
	echo '</div>';
	//include('item2.php');	
}
?>

<div class="container">
<div class="row">


  
</div>
</div>
<hr>


<div class="container">
<div class="row">

 

</div>
</div>
<hr>




  
</div>



     <hr>                


<footer class="text-muted well" id="last-footer">
    <section>
    <div class="row" style="font-size:11px;">
    <div class="container">
    <h3 class="subhead" style="text-align:center;">Thanks for visiting our website</h3>

      <div class="col-md-9">
      <div class="row" >
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="aboutus.php" style="color: white"><h5>About US</h5></a></button>
      </div>
      </div>
      </div>
      
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="faq.php" style="color: white"><h5>FAQs</h5></a></button>
      </div>
      </div>
      </div>
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <h5 style= "text-align: center;">Contact US</h5>
      <h7 allign="justify">Delaco (Main office) <br>Kotkantie 1, 90250<br>Oulu, Finland</h7>
      </div>
      </div>
      </div>
      <hr/>     
        </div><!--/.row inner--> 
    </div>
    
          </ul>   
        </form>   
    </div>
    </div>
      <footer>  <div class="row">
      <div class="container text-center">
        <h5>All Rights Reserved © 2017.</h5>
      </div>
      </div></footer>
       </div><!--/.container--> 
       </div><!--/.row outer--> 
    </section>
        </footer> 
     </div>
  
    
  


        <script src="js/bootstrap.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</body>
</html>