<?php
	define('DB_SERVER', 'localhost:3306');
	define('DB_USERNAME', 'OAMKTesting');
	define('DB_PASSWORD', 'Ql}O~HRt)-BE');
	define('DB_DATABASE', 'OAMKTestingImage');
	$db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>
