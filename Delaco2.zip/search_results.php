<?php
$area = $_POST['area'];
$date1 = $_POST['date1'];
$date2 = $_POST['date2'];
$pchoice = $_POST['price'];
$name = $_POST['name'];
switch($pchoice)
{
	case '1':
	$query = "SELECT * from items WHERE location = '".$area."' AND priceperday < 10";
	break;
	
	case '2':
	$query = "SELECT * from items WHERE (location = '".$area."') AND (priceperday BETWEEN 10 AND 30)";
	break;
	
	case '3':
	$query = "SELECT * from items WHERE (location = '".$area."') AND (priceperday BETWEEN 31 AND 50)";
	break;
	
	case '4':
	$query = "SELECT * from items WHERE (location = '".$area."') AND (priceperday BETWEEN 51 AND 100)";
	break;
	
	case '5':
	$query = "SELECT * from items WHERE location = '".$area."' AND priceperday > 100";
	break;
}

$link = mysqli_connect('localhost','root','root','oamktestingimage');


$result = mysqli_query($link,$query);
if (!$result) {
        echo 'MySQL Error: ' . mysqli_error();
        exit;
    }

$num_of_results = 0;
while($item = mysqli_fetch_assoc($result)) {
	$num_of_results = $num_of_results + 1;
    //echo $item['itemid']; 
}
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>title</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
   <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <style>
		  @import "http://fonts.googleapis.com/css?family=Roboto:300,400,500,700";

		.container { margin-top: 20px; }
		.mb20 { margin-bottom: 20px; } 

		hgroup { padding-left: 15px; border-bottom: 1px solid #ccc; }
		hgroup h1 { font: 500 normal 1.625em "Roboto",Arial,Verdana,sans-serif; color: #2a3644; margin-top: 0; line-height: 1.15; }
		hgroup h2.lead { font: normal normal 1.125em "Roboto",Arial,Verdana,sans-serif; color: #2a3644; margin: 0; padding-bottom: 10px; }

		.search-result .thumbnail { border-radius: 0 !important; }
		.search-result:first-child { margin-top: 0 !important; }
		.search-result { margin-top: 20px; }
		.search-result .col-md-2 { border-right: 1px dotted #ccc; min-height: 140px; }
		.search-result ul { padding-left: 0 !important; list-style: none;  }
		.search-result ul li { font: 400 normal .85em "Roboto",Arial,Verdana,sans-serif;  line-height: 30px; }
		.search-result ul li i { padding-right: 5px; }
		.search-result .col-md-7 { position: relative; }
		.search-result h3 { font: 500 normal 1.375em "Roboto",Arial,Verdana,sans-serif; margin-top: 0 !important; margin-bottom: 10px !important; }
		.search-result h3 > a, .search-result i { color: #248dc1 !important; }
		.search-result p { font: normal normal 1.125em "Roboto",Arial,Verdana,sans-serif; } 
		.search-result span.plus { position: absolute; right: 0; top: 126px; }
		.search-result span.plus a { background-color: #248dc1; padding: 5px 5px 3px 5px; }
		.search-result span.plus a:hover { background-color: #414141; }
		.search-result span.plus a i { color: #fff !important; }
		.search-result span.border { display: block; width: 97%; margin: 0 15px; border-bottom: 1px dotted #ccc; }
</style>
  
  </head>
  <body id="page-top" class="index">
     <nav id="mainNav" class="navbar navbar-default navbar-custom navbar-fixed-top">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="airbnb.php" style="color: rgb(0,128,128); font-family: Arial Black;"><img src="images/logo.png"  style="float:left; padding-right: 10px; margin-top: -10px;"><b>DELACO</b></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="airbnb.php"><span class="glyphicon glyphicon-home"></span></a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#">Browse Items</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#">Rent Your Items</a>
                    </li>
                    
                    <?php
                    if (!$_SESSION['login_user']){ ?>
                      <li>
                          <a class="page-scroll" href="login.php">Login</a>
                      </li>
                       <li>
                          <a class="page-scroll" href="signup.php">Sign up</a>
                      </li>
                    <?php } else {?>
                      <li>
                          <a class="page-scroll" href="myitem.php">My Item</a>
                      </li>
                      <li>
                          <a class="page-scroll" href="logout.php">Log Out</a>
                      </li>
                    <?php } ?>
                </ul>


                
    <form class="navbar-form navbar-left" role="search">
    <div class="form-group">
        <input type="text" class="form-control" placeholder="Item">
    </div>
    <button type="button" class="btn btn-info">
      <span class="glyphicon glyphicon-search"></span> Search
    </button>
</form>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
	<hr><hr><hr><hr>
  <div class="container">

    <hgroup class="mb20">
		<h1>Search Results</h1>
		<h2 class="lead"><strong class="text-danger"><?php echo $num_of_results; ?></strong> results were found for the search in <strong class="text-danger"><?php echo $area;?></strong></h2>								
	</hgroup>

    <section class="col-xs-12 col-sm-6 col-md-12">
	
	<?php
	$link = mysqli_connect('localhost','root','root','oamktestingimage');


	$result = mysqli_query($link,$query);
	if (!$result) {
        echo 'MySQL Error: ' . mysqli_error();
        exit;
    }
	
	while($item = mysqli_fetch_assoc($result)) {
		//$num_of_results = $num_of_results + 1;
		
		echo '<article class="search-result row">';
		echo '<div class="col-xs-12 col-sm-12 col-md-3">';
		echo '<a href="#" title="Lorem ipsum" class="thumbnail"><img src="item_image.php?id='.$item['itemid'].'" alt="Lorem ipsum" /></a>';
		echo '</div>';
		echo '<div class="col-xs-12 col-sm-12 col-md-2">';
		echo '<ul class="meta-search">';
		echo '<li><i class="glyphicon glyphicon-map-marker"></i><span>'.$item['location'].'</span></li>';
		echo '<li><i class="glyphicon glyphicon-euro"></i> <span>'.$item['priceperday'].'</span></li>';
		echo '<li><i class="glyphicon glyphicon-tags"></i> <span>Electronics, Phone</span></li>';
		echo '</ul>';
		echo '</div>';
		echo '<div class="col-xs-12 col-sm-12 col-md-7">';
		echo '<h3><a href="#" title="">'.$item['title'].'</a></h3>';
		echo '<p>'.$item['description'].'</p>';					
        echo '<span class="plus"><a href="#" title="Lorem ipsum"><i class="glyphicon glyphicon-plus"></i></a></span>';
		echo '</div>';
		echo '<span class="clearfix border"></span>';
		echo '</article>';	
		
	}
	?>


 

	

	</section>
</div>

<hr><hr>

<footer class="text-muted well" id="last-footer">
    <section>
    <div class="row" style="font-size:11px;">
    <div class="container">
    <h3 class="subhead" style="text-align:center;">Thanks for visiting our website</h3>

      <div class="col-md-9">
      <div class="row" >
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="aboutus.php" style="color: white"><h5>About US</h5></a></button>
      </div>
      </div>
      </div>
      
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <button type="button" class="btn btn-info"><a href="faq.php" style="color: white"><h5>FAQs</h5></a></button>
      </div>
      </div>
      </div>
      <div class="col-md-3">
      <div class="row footlinks">
      <div class="col-xs-12">
      <h5 style= "text-align: center;">Contact US</h5>
      <h7 allign="justify">Delaco (Main office) <br>Kotkantie 1, 90250<br>Oulu, Finland</h7>
      </div>
      </div>
      </div>
      <hr/>     
        </div><!--/.row inner--> 
    </div>
    
          </ul>   
        </form>   
    </div>
    </div>
      <footer>  <div class="row">
      <div class="container text-center">
        <h5>All Rights Reserved © 2017.</h5>
      </div>
      </div></footer>
       </div><!--/.container--> 
       </div><!--/.row outer--> 
    </section>
        </footer> 
 
  </body>
</html>